function randomGenerator(){

  var randomNumber;

  randomNumber = Math.floor(Math.random()*6);
  if(randomNumber === 0){
    return randomNumber+1;
  }else{
    return randomNumber;
  }

}

function CheckWinner(){

   let randomNumber1 = randomGenerator();
   let randomNumber2 = randomGenerator();

   if(randomNumber1 === randomNumber2){
     document.querySelector("h1").innerHTML = "Its a draw";
   }else if (randomNumber1<randomNumber2) {
     document.querySelector("h1").innerHTML = "Player2 wins";
  }else {
    document.querySelector("h1").innerHTML = "Player1 wins";
  }



document.querySelector("img").setAttribute("src","images/dice"+randomNumber1+".png");
document.querySelector("img").setAttribute("src","images/dice"+randomNumber2+".png");
}

CheckWinner();
